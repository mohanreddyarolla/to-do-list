
//fuction call that loads the previous list


previousList(parseInt(localStorage.getItem('count')));


function eventDone(count,don)
{
    let check=document.getElementById('check'+count);

    if(don==0)
    {
        localStorage.setItem("check"+count,1);
        check.innerHTML='<button  onclick="eventDone('+count+',1)"><img src="./images/done.png"></button>';
    }
    else
    {
        localStorage.setItem("check"+count,0);
        check.innerHTML='<button  onclick="eventDone('+count+',0)"><img src="./images/notdone.png"></button>';
    }
    
}

function previousList(listCount)
{
    if(localStorage.length==1)
    {
        localStorage.setItem('count',0);
    }


    //loading previous data

    console.log(listCount);

    let ul=document.getElementById('listUl');

    for(let i=1;i<=listCount;i++)
    {
        if(localStorage.getItem(i) != null)
        {
            let li=document.createElement('li');
            li.setAttribute('id','list'+i);
            console.log(localStorage.getItem(i));

            if (localStorage.getItem('check'+i)==0)
            {
                li.innerHTML='<span id="check'+i+'"><button  onclick="eventDone('+i+',0)"><img src="./images/notdone.png"></button></span><span class="currentEvent">'+localStorage.getItem(i)+'</span><span ><button  onclick="deleteEvent('+i+')"  ><img onmouseover="setNewImage('+i+')" onmouseout="setOldImage('+i+')" id="deleteBtn'+i+'"  src="./images/del1.png"></button></span>';
            }
            else
            {
                li.innerHTML='<span id="check'+i+'"><button  onclick="eventDone('+i+',1)"><img src="./images/done.png"></button></span><span class="currentEvent">'+localStorage.getItem(i)+'</span><span ><button  onclick="deleteEvent('+i+')"  ><img onmouseover="setNewImage('+i+')" onmouseout="setOldImage('+i+')" id="deleteBtn'+i+'"  src="./images/del1.png"></button></span>';
            }
            
            ul.appendChild(li);
        }
        
    }

}

console.log(localStorage.length);
function addToList()
{
    //calculating current list count

    if(localStorage.length==0)
    {
        localStorage.setItem('count',0);
    }
    
    
    let listCount=parseInt(localStorage.getItem('count'));

    
    //storing the event text

    let inputText=document.getElementById('inputText');
    let ul=document.getElementById('listUl');

    listCount++;
    localStorage.setItem('count',parseInt(localStorage.getItem('count'))+1);
    localStorage.setItem(listCount,inputText.value);
    localStorage.setItem('check'+listCount,0);

          
    //appending the the event
    

    let li=document.createElement('li');
    li.setAttribute('id','list'+listCount);
    li.innerHTML='<span id="check'+listCount+'"><button onclick="eventDone('+listCount+',0)"><img src="./images/notdone.png"></button></span><span class="currentEvent">'+inputText.value+'</span> <span><button   onclick="deleteEvent('+listCount+')" ><img  onmouseover="setNewImage('+listCount+')" onmouseout="setOldImage('+listCount+')" id="deleteBtn'+listCount+'" src="./images/del1.png"></button></span>';
    ul.appendChild(li);

    console.log(li);

    console.log(localStorage.getItem('listCount'));
}

function setNewImage(listCount)
{
    document.getElementById('deleteBtn'+listCount).src="./images/del2.png";
}

function setOldImage(listCount)
{
    document.getElementById('deleteBtn'+listCount).src="./images/del1.png";
}

function deleteEvent(listCount)
{
    localStorage.removeItem(listCount);
    localStorage.removeItem('check'+listCount);
    list=document.getElementById('list'+listCount);
    list.remove();

    
}








    



